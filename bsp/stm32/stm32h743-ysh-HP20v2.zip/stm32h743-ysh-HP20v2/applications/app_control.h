#ifndef __APP_CONTROL_H__
#define __APP_CONTROL_H__
#include <rtdef.h>

void adc_control_server(void);

#endif
