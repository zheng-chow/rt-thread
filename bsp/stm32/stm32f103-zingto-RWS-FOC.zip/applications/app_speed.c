#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>
#include <drv_foc.h>
#include <drv_hall.h>
#include <app_speed.h>
#include <app_can.h>
#include <app_pid.h>

#define PID_FREQ    1000
#define DeltaT      (1.0f / 1000);


#if defined(AXIS_PITCH)
#define PID_KP       0.00000045
#define PID_KI      (PID_KP/10)
#define ACC_ERR 0.3
#define MAX_PID_RES 0.6
#define MIN_PID_RES 0.04

#elif defined(AXIS_YAW)

#define PID_KP       0.00000045
#define PID_KI      (PID_KP/10)
#define ACC_ERR 0.3
#define MAX_PID_RES 0.6
#define MIN_PID_RES 0.04

#else
#error "no pid parameter"
#endif


//#define PID_KP      UP_PID_KP
//#//define PID_KI      UP_PID_KI

//#define UP_PID_KP       0.00000045
//#define UP_PID_KI      (PID_KP/10)
/*
#define DOWN_PID_KP     0.00000045
#define DOWN_PID_KI      (PID_KP/20)*/


//#define ZERO_SPEED_DEAD 1.0/400


//#define DRV_DEBUG
#define LOG_TAG             "app.speed"
#include <drv_log.h>

static struct rt_event evt_speed;
static struct rt_mailbox    mb_speed;
ALIGN(RT_ALIGN_SIZE)
static float speed_buffer;

static rt_bool_t bPrint = RT_FALSE;
static float     fPrintSpeed = 0;
void printf_entry(void* parameter){
    while(1){
        if (bPrint)
            rt_kprintf("%d\n", (int)(fPrintSpeed+0.5));
        rt_thread_mdelay(200);
    }
}
int app_printf(void){
    rt_thread_t tid = rt_thread_create("spdprt",printf_entry, RT_NULL, 2048, 20, RT_TICK_PER_SECOND/10);
    if (tid) rt_thread_startup(tid);
    return 0;
}
//INIT_APP_EXPORT(app_printf);
static rt_err_t speed_timeout_call(rt_device_t dev, rt_size_t size){
    rt_event_send(&evt_speed, SPEED_CONTROL_ADJUST_MOTOR);
    return RT_EOK;
}
void speed_pid(void* parameter){
    PID_t pid;
    uint32_t evt;
    rt_hwtimer_mode_t mode = HWTIMER_MODE_PERIOD; 
    rt_hwtimerval_t timeout_s;
    float targetSpeed = 0.0;
    rt_bool_t bPwmDevOpened = RT_FALSE;
    rt_tick_t tickBreath = 0;
    //float coefM = 0.0;
    pwm_update_t pwm_param = {.detAngle=90};
    
    rt_device_t tim_dev = rt_device_find("timer5");    
    rt_device_t pwm_dev = rt_device_find("pwmcom");
    rt_device_t hall_dev = rt_device_find("hall");
    
    
    rt_event_init(&evt_speed, SPEED_EVT_NAME, RT_IPC_FLAG_FIFO);
    rt_mb_init(&mb_speed, "mbspeed", &speed_buffer, sizeof(speed_buffer)/4, RT_IPC_FLAG_FIFO);
    //rt_device_set_rx_indicate(tim_dev, speed_timeout_call);  
    RT_ASSERT(tim_dev);
    
    RT_ASSERT(pwm_dev && hall_dev);    
    rt_device_open(hall_dev, 0);
    //rt_device_open(pwm_dev, 0); 

    pid_init(&pid, PID_KP, PID_KI, 0);  
    if (PID_KI != 0) 
        pid_threshold(&pid, ACC_ERR / PID_KI, MAX_PID_RES, 1);
    else  pid_threshold(&pid, 0, MAX_PID_RES, 1);
    
    /*pid_enable(&pid, RT_TRUE);*/
    rt_device_open(tim_dev, RT_DEVICE_OFLAG_RDWR);
    rt_device_set_rx_indicate(tim_dev, speed_timeout_call);

    mode = HWTIMER_MODE_PERIOD;
    rt_device_control(tim_dev, HWTIMER_CTRL_MODE_SET, &mode);
    timeout_s.sec = 0;     
    timeout_s.usec = 1000000/PID_FREQ;    
    rt_device_write(tim_dev, 0, &timeout_s, sizeof(timeout_s));

    rt_event_recv(&evt_speed, SPEED_CONTROL_ADJUST_MOTOR, RT_EVENT_FLAG_OR|RT_EVENT_FLAG_CLEAR, RT_WAITING_FOREVER, &evt);
    
    while (1){
        rt_event_recv(&evt_speed, SPEED_CONTROL_EVENT, RT_EVENT_FLAG_OR|RT_EVENT_FLAG_CLEAR, RT_WAITING_FOREVER, &evt);
        if (RT_EOK == rt_mb_recv(&mb_speed, (rt_ubase_t*)&targetSpeed, 0)){
            LOG_D("target speed: %d.%d", (int)targetSpeed, (int)((targetSpeed-(int)targetSpeed)));
            tickBreath = rt_tick_get();
        }
        if ((evt & SPEED_CONTROL_OPEN_MOTOR) && !bPwmDevOpened){         
            rt_device_open(pwm_dev, 0);
            bPwmDevOpened = RT_TRUE;
            targetSpeed = 0;
            tickBreath = rt_tick_get();
            bPrint = bPwmDevOpened;
        }
        else if ((evt & SPEED_CONTROL_CLOSE_MOTOR) && bPwmDevOpened){
            rt_device_close(pwm_dev);
            bPwmDevOpened = RT_FALSE;
            pid_reset(&pid, 0);
            targetSpeed = 0;
            bPrint = bPwmDevOpened;
            pid_enable(&pid, RT_FALSE);                   

       }      
       if ((evt & SPEED_CONTROL_ADJUST_MOTOR) && bPwmDevOpened){  
           if (!pid.bEnable){
                float power = foc_fast_get_power();
                if ((power > 20) && (power < 50)){
                    LOG_I("power detect error, %d V", (int)(power+0.5f));                    
                    power = power / 24;
                    pid_init(&pid, PID_KP/power, PID_KI/power, 0);  
                    if (PID_KI != 0) 
                    pid_threshold(&pid, ACC_ERR * power / PID_KI, MAX_PID_RES, 1);
                    else  pid_threshold(&pid, 0, MAX_PID_RES, 1);            
                    pid_enable(&pid, RT_TRUE);   
                }
                else{
                    LOG_E("power detect error, %d V", (int)(power+0.5f));
                }           
           }
           else{      
                const float maxIncValue = 0.1;
                float incValue;
                pid.measValue = hall_fast_get_speed();               
                pid.targValue = targetSpeed;	
                pid_update3(&pid);
               /*
                incValue = pid.resValue - pid.resLastValue;
                if (incValue > maxIncValue) incValue = maxIncValue;
                else if (incValue < -maxIncValue) incValue = -maxIncValue;
                pid.resValue = pid.resLastValue + incValue;*/
                if (pid.resValue< 0){
                    pwm_param.detAngle = -90;
                    pid.resValue = -pid.resValue;
                }
                else pwm_param.detAngle =90;
                //if (pid.lastErr > 60){
                //  if (pid.resValue < MIN_PID_RES) pid.resValue = MIN_PID_RES;
                //}
                /*if (((pid.measValue<=0) && (pid.targValue>0))
                    || ((pid.measValue>=0) && (pid.targValue<0))){
                    if ((pid.lastErr>0&& pid.accErr<0)||(pid.lastErr<0&& pid.accErr>0))
                        pid.accErr *= 0.8;
                }*/
                pwm_param.coefM = pid.resValue;
                rt_device_control(pwm_dev, PWM3_CONTROL_UPDATE, &pwm_param); 
                tickBreath = rt_tick_get();//**********************************force do 
                fPrintSpeed = pid.measValue;
                //bPrint = (targetSpeed != 0);
                //fPrintSpeed = ((GPIOC->IDR)>>6) & 0x07;//pid.resValue * 1000;
                //fPrintSpeed = foc_fast_get_power();
            }
        }  
        else if (bPwmDevOpened){
            rt_tick_t currTick = rt_tick_get();
            if ((currTick - tickBreath) > (RT_TICK_PER_SECOND/2)) {
                if (targetSpeed != 0){
                    targetSpeed = 0;
                    rt_mb_send(&mb_speed, *(rt_ubase_t*)&targetSpeed);   
                }                    
            }
        }
    }     
}

int app_speed(void){
    rt_thread_t tid = rt_thread_create("speedpid",speed_pid, RT_NULL, 2048, 16, RT_TICK_PER_SECOND/10);
    if (tid) return rt_thread_startup(tid);
    return -RT_ERROR;
}
INIT_APP_EXPORT(app_speed);


#ifdef RT_USING_FINSH
#include <finsh.h>
static void speed(uint8_t argc, char **argv){
    if (argc != 2) {
        LOG_E("command format: speed 40");
        return;
    }
    float speed = atof(argv[1]);
    speed *= 2100;
    rt_mailbox_t mb =     (rt_mailbox_t)rt_object_find("mbspeed", RT_Object_Class_MailBox);
    rt_mb_send(mb, *(rt_ubase_t*)&speed);    
}
FINSH_FUNCTION_EXPORT_ALIAS(speed, __cmd_speed, set speed);

static void pwmenable(uint8_t argc, char **argv){
    if (argc != 2) {
        LOG_E("command format: speed 40");
        return;
    }
    rt_event_t evt = (rt_event_t) rt_object_find(SPEED_EVT_NAME, RT_Object_Class_Event);
    if (evt){
        int enable = atoi(argv[1]);
        if (enable != 0){           
            rt_event_send(evt, SPEED_CONTROL_OPEN_MOTOR);
        }
        else{
            rt_event_send(evt, SPEED_CONTROL_CLOSE_MOTOR);
        }
    }
}
FINSH_FUNCTION_EXPORT_ALIAS(pwmenable, __cmd_pwmenable, enable or disable control speed);
#endif /* RT_USING_FINSH */
