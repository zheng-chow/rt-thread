#ifndef __APP_ABS_ENCODER_H__
#define __APP_ABS_ENCODER_H__

float get_speed_from_encoder(void);
#endif
